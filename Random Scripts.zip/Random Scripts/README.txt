A bunch of random scripts that help me in small ways

To Run:
	Double click the script to run

Scripts:
	Clear Files with Extension
		Double click to run
		Enter a certain extension to delete all files with it in the same folder as the script
	AddBookmark2PDF
		Fill in 1st column of excel with page numbers
		Fill in 2nd column of excel with bookmark titles associated with page number
		Double click script to run
		Choose PDF file
		Says "Finished" when done
	FlattenPDf
		Asks user to choose a PDF file to flatten or can be drag and dropped onto the script
		If file exists then asks user if it's ok to continue
		Flattens and saves as new file within same folder with "_FLATTENED" added to the title

Log:
	***10/02/2015***
	Added in ability to drag and drop files onto FlattenPDF
	***09/29/2015***
	Fixed Error Handling with Check Error Sub
	***09/28/2015***
	Added in the option to rerun "Clear Files with Extension" and "FlattenPDF"
	Added in Error Handling
	***09/21/2015***
	Created "AddBookmark2PDF" folder with excel and script files
	***09/14/2015***
	Created "Clear Files with Extension" script